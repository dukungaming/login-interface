# Login Interface - User Characteristics

## 🎯 Tujuan
Mengembangkan form login untuk mengukur 9 karakteristik pengguna berdasarkan panduan software requirements.

## 🧪 Karakteristik yang Diukur
- Usia pengguna
- Email
- Tingkat pengalaman (1–5)
- Preferensi bahasa
- Kata sandi (untuk keamanan dasar)

## 🚀 Cara Menjalankan

### Frontend
1. Buka `index.html` di browser

### Backend
1. Buka terminal dan masuk ke folder `server`
2. Jalankan perintah berikut:
   ```bash
   npm init -y
   npm install express cors
   node server.js
