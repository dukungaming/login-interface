<?php
$koneksi = mysqli_connect("localhost", "root", "", "login_system");

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Escape string untuk keamanan
$username = mysqli_real_escape_string($koneksi, $username);
$password = md5($password); // jika kamu menyimpan pakai MD5

$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = mysqli_query($koneksi, $query);

if (mysqli_num_rows($result) == 1) {
    echo "<h2>Login berhasil. Selamat datang, $username!</h2>";
} else {
    echo "<h2>Login gagal. Coba lagi!</h2>";
}
?>
